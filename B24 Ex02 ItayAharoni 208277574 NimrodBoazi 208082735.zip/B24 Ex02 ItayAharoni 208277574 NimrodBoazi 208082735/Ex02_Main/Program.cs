﻿namespace Ex02_Memory_Game
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            ConsoleUI consoleUI = new ConsoleUI();
            consoleUI.StartGame();
        }
    }
}
