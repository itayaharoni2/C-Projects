﻿namespace Ex04.Menus.Interfaces
{
    public interface ISelectedListener
    {
        void NotifySelected(MenuItem i_SelectedMenuItem);
    }
}
