﻿namespace Ex04.Menus.Test
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            MenuTest.RunTest();
        }
    }
}
