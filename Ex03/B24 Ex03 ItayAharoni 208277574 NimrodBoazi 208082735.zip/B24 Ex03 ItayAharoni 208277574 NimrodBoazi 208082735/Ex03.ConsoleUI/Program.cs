﻿namespace Ex03.ConsoleUI
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            ConsoleUI startProgram = new ConsoleUI();

            startProgram.LaunchGarageManagementSystem();
        }
    }
}